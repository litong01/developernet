#ifndef _NET_INETPEER_WRAPPER_H
#define _NET_INETPEER_WRAPPER_H

#include_next <net/inetpeer.h>

#ifdef OVS_FRAGMENT_BACKPORT
static inline struct inet_peer *rpl_inet_getpeer_v4(struct inet_peer_base *base,
						    __be32 v4daddr, int vif,
						    int create)
{
	return inet_getpeer_v4(base, v4daddr, create);
}
#define inet_getpeer_v4 rpl_inet_getpeer_v4
#endif /* OVS_FRAGMENT_BACKPORT */

#endif /* _NET_INETPEER_WRAPPER_H */
