#!/bin/bash
set -ev
pip install --user six
